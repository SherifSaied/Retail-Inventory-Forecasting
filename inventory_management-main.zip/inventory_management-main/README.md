# inventory_management
Project 1 Depi

This is DEPI graduation project.. 
Project Name: Inventory Management System.

Project Contributers:

1- Mohammed Sherif
2- Mahmoud Fahim
3- Shaimaa Tarek
4- Sherif Said
5- Sarah Shabaan
